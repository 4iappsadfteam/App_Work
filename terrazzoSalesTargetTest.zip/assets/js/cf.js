jQuery(document).ready(function () {
    getPod();
});
var pod_daas = '';
var pod_paas = '';
var pod_saas = '';
var podLoaded = 0;
function getPod() {
    var url = "getPodInfo.jsp";
    $.ajax({
        type: "GET",
        url: url,
        success: function (data) {
            if(data==='edgt-test'){
                $(".navbar").css("background-color","#66817e !important").slideDown();
                pod_daas = 'apex2';
                pod_paas = 'java';
                podLoaded = 1;
            }
            else if(data==='edgt'){
                pod_daas = 'apex';
                pod_paas = 'java2';
                podLoaded = 1;
            }
            if(podLoaded === 1){
                pod_saas = data;                
                var html="<div class='navbar-fixed-bottom text-center' style='font-size:9px;background:#e5e5e5;color:#999;'>";
                html+="<span class='pull-left' >PaaS: <b style='color:#999;text-transform:uppercase;'>"+pod_paas+"</b></span>";
                html+="<span class='' >SaaS: <b style='color:#999;text-transform:uppercase;'>"+pod_saas+"</b></span>";
                html+="<span class='pull-right' >DaaS: <b style='color:#999;text-transform:uppercase;'>"+pod_daas+"</b></span>";
                html+="</div>";
                $("body").append(html);                
                firstFunctions();
            }
            else{
                alert("There is an issue retreiving POD information. Try again later.");
            }
        }
    });
}